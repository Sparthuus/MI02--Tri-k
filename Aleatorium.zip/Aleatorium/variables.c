/*Variable qu'on peut varier*/
    #define HACK 0
    //#define NBSALLE (rand() % 6 + 5)//Définir le nombre de salle générable
    #define NBSALLEMAX 10
    #define MAX 5 //Taille de la Salle au maximum
    #define MAP (NBSALLEMAX * MAX + VISION * 2) //Définir la taille de Map
    #define VISION 9 //Définir la vision du joueur
    #define MAXXP 5 //Définir le maximum d'expérience requis
    #define TEMPSLIMITE 20*60
/*Variable qu'il ne faut pas changer*/
    #define NBDEJEU 11 //Nb de jeu dispo
    #define MENU 10
    #define MENULONG 17
    #define MENULARG 12
    #define PARAMLONG 17
    #define PARAMLARG 7
    #define COURSE 10
    /*Alexandre*/
    #define TAILLE 3
    #define TAILLE2 5
    #define TAILLE3 40
    #define MOUTONS 5
    //bos
        #define COMPTEURFLASH 6
        #define COMPTEURULT 5
        #define TEMPSSOUSFLASH 1
        #define TEMPSSOUSULT 0
        #define MONSTRES 1
    //
    #define taille 6
    #define MANCHE 1
    /*Mathieu*/
    #define A 20
    #define QUESTION 8
    #define NBQUESTION 8 